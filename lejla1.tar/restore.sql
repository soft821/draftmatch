--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.13
-- Dumped by pg_dump version 9.5.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.game_slate DROP CONSTRAINT game_slate_slate_id_foreign;
ALTER TABLE ONLY public.game_slate DROP CONSTRAINT game_slate_game_id_foreign;
ALTER TABLE ONLY public.fantasy_player_slate DROP CONSTRAINT fantasy_player_slate_slate_id_foreign;
ALTER TABLE ONLY public.fantasy_player_slate DROP CONSTRAINT fantasy_player_slate_fantasy_player_id_foreign;
DROP INDEX public.slate_index;
DROP INDEX public.password_resets_email_index;
DROP INDEX public.game_slate_slate_id_index;
DROP INDEX public.game_slate_game_id_index;
DROP INDEX public.game_index;
DROP INDEX public.fantasy_player_slate_slate_id_index;
DROP INDEX public.fantasy_player_slate_fantasy_player_id_index;
DROP INDEX public.fantasy_index;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_username_unique;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_email_unique;
ALTER TABLE ONLY public.time_frames DROP CONSTRAINT time_frames_pkey;
ALTER TABLE ONLY public.slates DROP CONSTRAINT slates_id_unique;
ALTER TABLE ONLY public.promo_codes DROP CONSTRAINT promo_codes_pkey;
ALTER TABLE ONLY public.migrations DROP CONSTRAINT migrations_pkey;
ALTER TABLE ONLY public.invoices DROP CONSTRAINT invoices_pkey;
ALTER TABLE ONLY public.games DROP CONSTRAINT games_id_unique;
ALTER TABLE ONLY public.fantasy_players DROP CONSTRAINT fantasy_players_id_unique;
ALTER TABLE ONLY public.entries DROP CONSTRAINT entries_pkey;
ALTER TABLE ONLY public.contests DROP CONSTRAINT contests_id_unique;
ALTER TABLE ONLY public.bit_coin_infos DROP CONSTRAINT bit_coin_infos_id_unique;
ALTER TABLE public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.time_frames ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.promo_codes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.migrations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.invoices ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.entries ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.users_id_seq;
DROP TABLE public.users;
DROP SEQUENCE public.time_frames_id_seq;
DROP TABLE public.time_frames;
DROP TABLE public.slates;
DROP SEQUENCE public.promo_codes_id_seq;
DROP TABLE public.promo_codes;
DROP TABLE public.password_resets;
DROP SEQUENCE public.migrations_id_seq;
DROP TABLE public.migrations;
DROP SEQUENCE public.invoices_id_seq;
DROP TABLE public.invoices;
DROP TABLE public.games;
DROP TABLE public.game_slate;
DROP TABLE public.fantasy_players;
DROP TABLE public.fantasy_player_slate;
DROP SEQUENCE public.entries_id_seq;
DROP TABLE public.entries;
DROP TABLE public.contests;
DROP TABLE public.bit_coin_infos;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: bit_coin_infos; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.bit_coin_infos (
    id character varying(255) NOT NULL,
    rate double precision,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.bit_coin_infos OWNER TO root;

--
-- Name: contests; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.contests (
    id character varying(255) NOT NULL,
    "matchupType" character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    size integer NOT NULL,
    "entryFee" integer NOT NULL,
    tier character varying(255),
    "position" character varying(255) NOT NULL,
    filled boolean NOT NULL,
    status character varying(255) NOT NULL,
    slate_id character varying(255) NOT NULL,
    start timestamp(0) without time zone NOT NULL,
    user_id integer NOT NULL,
    group_id character varying(255),
    admin_contest boolean DEFAULT false NOT NULL,
    private boolean DEFAULT false NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.contests OWNER TO root;

--
-- Name: entries; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.entries (
    id integer NOT NULL,
    contest_id character varying(255) NOT NULL,
    slate_id character varying(255) NOT NULL,
    user_id integer,
    username character varying(255),
    fantasy_player_id character varying(255) NOT NULL,
    game_id character varying(255) NOT NULL,
    owner boolean NOT NULL,
    points double precision DEFAULT '0'::double precision NOT NULL,
    winning double precision DEFAULT '0'::double precision NOT NULL,
    winner boolean DEFAULT false NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.entries OWNER TO root;

--
-- Name: entries_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.entries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.entries_id_seq OWNER TO root;

--
-- Name: entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.entries_id_seq OWNED BY public.entries.id;


--
-- Name: fantasy_player_slate; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.fantasy_player_slate (
    fantasy_player_id character varying(255) NOT NULL,
    slate_id character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.fantasy_player_slate OWNER TO root;

--
-- Name: fantasy_players; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.fantasy_players (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    team character varying(255) NOT NULL,
    game_id character varying(255),
    "position" character varying(255) NOT NULL,
    status character varying(255),
    status_code character varying(255),
    status_color character varying(255),
    tier character varying(255),
    salary integer NOT NULL,
    activated boolean DEFAULT false NOT NULL,
    played boolean DEFAULT false NOT NULL,
    tds character varying(255) DEFAULT '0'::character varying NOT NULL,
    "paYd" character varying(255) DEFAULT '0'::character varying NOT NULL,
    "paTd" character varying(255) DEFAULT '0'::character varying NOT NULL,
    "int" character varying(255) DEFAULT '0'::character varying NOT NULL,
    "ruYd" character varying(255) DEFAULT '0'::character varying NOT NULL,
    "ruTd" character varying(255) DEFAULT '0'::character varying NOT NULL,
    fum character varying(255) DEFAULT '0'::character varying NOT NULL,
    rec character varying(255) DEFAULT '0'::character varying NOT NULL,
    "reYd" character varying(255) DEFAULT '0'::character varying NOT NULL,
    "reTd" character varying(255) DEFAULT '0'::character varying NOT NULL,
    "krTd" character varying(255) DEFAULT '0'::character varying NOT NULL,
    "prTd" character varying(255) DEFAULT '0'::character varying NOT NULL,
    "frTd" character varying(255) DEFAULT '0'::character varying NOT NULL,
    "convRec" character varying(255) DEFAULT '0'::character varying NOT NULL,
    "convPass" character varying(255) DEFAULT '0'::character varying NOT NULL,
    "convRuns" character varying(255) DEFAULT '0'::character varying NOT NULL,
    fg0_39 character varying(255) DEFAULT '0'::character varying NOT NULL,
    fg40_49 character varying(255) DEFAULT '0'::character varying NOT NULL,
    fg50 character varying(255) DEFAULT '0'::character varying NOT NULL,
    xp character varying(255) DEFAULT '0'::character varying NOT NULL,
    sacks character varying(255) DEFAULT '0'::character varying NOT NULL,
    "defInt" character varying(255) DEFAULT '0'::character varying NOT NULL,
    "fumRec" character varying(255) DEFAULT '0'::character varying NOT NULL,
    safeties character varying(255) DEFAULT '0'::character varying NOT NULL,
    "defTds" character varying(255) DEFAULT '0'::character varying NOT NULL,
    "ptsA" character varying(255) DEFAULT '0'::character varying NOT NULL,
    "convRet" character varying(255) DEFAULT '0'::character varying NOT NULL,
    fps character varying(255) DEFAULT '0'::character varying NOT NULL,
    fps_live character varying(255) DEFAULT '0'::character varying NOT NULL,
    active boolean DEFAULT true NOT NULL,
    updated boolean DEFAULT false NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.fantasy_players OWNER TO root;

--
-- Name: game_slate; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.game_slate (
    game_id character varying(255) NOT NULL,
    slate_id character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.game_slate OWNER TO root;

--
-- Name: games; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.games (
    id character varying(255) NOT NULL,
    year character varying(255) NOT NULL,
    "seasonType" character varying(255) NOT NULL,
    week character varying(255) NOT NULL,
    day character varying(255) NOT NULL,
    date timestamp(0) without time zone NOT NULL,
    "time" character varying(255) NOT NULL,
    "homeScore" integer NOT NULL,
    "awayScore" integer NOT NULL,
    "homeTeam" character varying(255) NOT NULL,
    "awayTeam" character varying(255) NOT NULL,
    status character varying(255) DEFAULT 'PENDING'::character varying NOT NULL,
    quarter character varying(255),
    overtime boolean NOT NULL,
    time_remaining character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    game_key character varying(50) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE public.games OWNER TO root;

--
-- Name: invoices; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.invoices (
    id integer NOT NULL,
    "invoiceId" character varying(255),
    email character varying(255) NOT NULL,
    user_id integer NOT NULL,
    amount double precision NOT NULL,
    currency character varying(255) NOT NULL,
    description character varying(255) NOT NULL,
    status character varying(255) NOT NULL,
    "createdAt" timestamp(0) without time zone,
    type character varying(255) NOT NULL,
    retries integer DEFAULT 0 NOT NULL,
    checked boolean DEFAULT false NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.invoices OWNER TO root;

--
-- Name: invoices_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.invoices_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.invoices_id_seq OWNER TO root;

--
-- Name: invoices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.invoices_id_seq OWNED BY public.invoices.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


ALTER TABLE public.migrations OWNER TO root;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migrations_id_seq OWNER TO root;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: password_resets; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.password_resets (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp(0) without time zone
);


ALTER TABLE public.password_resets OWNER TO root;

--
-- Name: promo_codes; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.promo_codes (
    id integer NOT NULL,
    email character varying(30) NOT NULL,
    code character varying(20) NOT NULL,
    expired bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.promo_codes OWNER TO root;

--
-- Name: promo_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.promo_codes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.promo_codes_id_seq OWNER TO root;

--
-- Name: promo_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.promo_codes_id_seq OWNED BY public.promo_codes.id;


--
-- Name: slates; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.slates (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    "firstDay" character varying(255) NOT NULL,
    "lastDay" character varying(255) NOT NULL,
    active boolean NOT NULL,
    status character varying(255) DEFAULT 'PENDING'::character varying NOT NULL,
    "firstGame" timestamp(0) without time zone,
    "lastGame" timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.slates OWNER TO root;

--
-- Name: time_frames; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.time_frames (
    id integer NOT NULL,
    api_week character varying(255),
    api_season character varying(255),
    week character varying(255),
    season character varying(255) NOT NULL,
    start_date timestamp(0) without time zone NOT NULL,
    first_game timestamp(0) without time zone NOT NULL,
    last_game timestamp(0) without time zone NOT NULL,
    season_type character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    status character varying(255) DEFAULT 'current'::character varying NOT NULL
);


ALTER TABLE public.time_frames OWNER TO root;

--
-- Name: time_frames_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.time_frames_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.time_frames_id_seq OWNER TO root;

--
-- Name: time_frames_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.time_frames_id_seq OWNED BY public.time_frames.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.users (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    username character varying(255) NOT NULL,
    role character varying(255) DEFAULT 'user'::character varying NOT NULL,
    balance double precision DEFAULT '0'::double precision NOT NULL,
    status character varying(255) DEFAULT 'active'::character varying NOT NULL,
    wins double precision DEFAULT '0'::double precision NOT NULL,
    loses double precision DEFAULT '0'::double precision NOT NULL,
    history_count double precision DEFAULT '0'::double precision NOT NULL,
    history_entry double precision DEFAULT '0'::double precision NOT NULL,
    history_winning double precision DEFAULT '0'::double precision NOT NULL,
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.users OWNER TO root;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO root;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.entries ALTER COLUMN id SET DEFAULT nextval('public.entries_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.invoices ALTER COLUMN id SET DEFAULT nextval('public.invoices_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.promo_codes ALTER COLUMN id SET DEFAULT nextval('public.promo_codes_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.time_frames ALTER COLUMN id SET DEFAULT nextval('public.time_frames_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: bit_coin_infos; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.bit_coin_infos (id, rate, created_at, updated_at) FROM stdin;
\.
COPY public.bit_coin_infos (id, rate, created_at, updated_at) FROM '$$PATH$$/2268.dat';

--
-- Data for Name: contests; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.contests (id, "matchupType", type, size, "entryFee", tier, "position", filled, status, slate_id, start, user_id, group_id, admin_contest, private, created_at, updated_at) FROM stdin;
\.
COPY public.contests (id, "matchupType", type, size, "entryFee", tier, "position", filled, status, slate_id, start, user_id, group_id, admin_contest, private, created_at, updated_at) FROM '$$PATH$$/2269.dat';

--
-- Data for Name: entries; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.entries (id, contest_id, slate_id, user_id, username, fantasy_player_id, game_id, owner, points, winning, winner, created_at, updated_at) FROM stdin;
\.
COPY public.entries (id, contest_id, slate_id, user_id, username, fantasy_player_id, game_id, owner, points, winning, winner, created_at, updated_at) FROM '$$PATH$$/2270.dat';

--
-- Name: entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.entries_id_seq', 1579, true);


--
-- Data for Name: fantasy_player_slate; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.fantasy_player_slate (fantasy_player_id, slate_id, created_at, updated_at) FROM stdin;
\.
COPY public.fantasy_player_slate (fantasy_player_id, slate_id, created_at, updated_at) FROM '$$PATH$$/2272.dat';

--
-- Data for Name: fantasy_players; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.fantasy_players (id, name, team, game_id, "position", status, status_code, status_color, tier, salary, activated, played, tds, "paYd", "paTd", "int", "ruYd", "ruTd", fum, rec, "reYd", "reTd", "krTd", "prTd", "frTd", "convRec", "convPass", "convRuns", fg0_39, fg40_49, fg50, xp, sacks, "defInt", "fumRec", safeties, "defTds", "ptsA", "convRet", fps, fps_live, active, updated, created_at, updated_at) FROM stdin;
\.
COPY public.fantasy_players (id, name, team, game_id, "position", status, status_code, status_color, tier, salary, activated, played, tds, "paYd", "paTd", "int", "ruYd", "ruTd", fum, rec, "reYd", "reTd", "krTd", "prTd", "frTd", "convRec", "convPass", "convRuns", fg0_39, fg40_49, fg50, xp, sacks, "defInt", "fumRec", safeties, "defTds", "ptsA", "convRet", fps, fps_live, active, updated, created_at, updated_at) FROM '$$PATH$$/2273.dat';

--
-- Data for Name: game_slate; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.game_slate (game_id, slate_id, created_at, updated_at) FROM stdin;
\.
COPY public.game_slate (game_id, slate_id, created_at, updated_at) FROM '$$PATH$$/2274.dat';

--
-- Data for Name: games; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.games (id, year, "seasonType", week, day, date, "time", "homeScore", "awayScore", "homeTeam", "awayTeam", status, quarter, overtime, time_remaining, created_at, updated_at, game_key) FROM stdin;
\.
COPY public.games (id, year, "seasonType", week, day, date, "time", "homeScore", "awayScore", "homeTeam", "awayTeam", status, quarter, overtime, time_remaining, created_at, updated_at, game_key) FROM '$$PATH$$/2275.dat';

--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.invoices (id, "invoiceId", email, user_id, amount, currency, description, status, "createdAt", type, retries, checked, created_at, updated_at) FROM stdin;
\.
COPY public.invoices (id, "invoiceId", email, user_id, amount, currency, description, status, "createdAt", type, retries, checked, created_at, updated_at) FROM '$$PATH$$/2276.dat';

--
-- Name: invoices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.invoices_id_seq', 91, true);


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.migrations (id, migration, batch) FROM stdin;
\.
COPY public.migrations (id, migration, batch) FROM '$$PATH$$/2278.dat';

--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.migrations_id_seq', 12, true);


--
-- Data for Name: password_resets; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.password_resets (email, token, created_at) FROM stdin;
\.
COPY public.password_resets (email, token, created_at) FROM '$$PATH$$/2280.dat';

--
-- Data for Name: promo_codes; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.promo_codes (id, email, code, expired, created_at, updated_at) FROM stdin;
\.
COPY public.promo_codes (id, email, code, expired, created_at, updated_at) FROM '$$PATH$$/2287.dat';

--
-- Name: promo_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.promo_codes_id_seq', 3, true);


--
-- Data for Name: slates; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.slates (id, name, "firstDay", "lastDay", active, status, "firstGame", "lastGame", created_at, updated_at) FROM stdin;
\.
COPY public.slates (id, name, "firstDay", "lastDay", active, status, "firstGame", "lastGame", created_at, updated_at) FROM '$$PATH$$/2281.dat';

--
-- Data for Name: time_frames; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.time_frames (id, api_week, api_season, week, season, start_date, first_game, last_game, season_type, created_at, updated_at, status) FROM stdin;
\.
COPY public.time_frames (id, api_week, api_season, week, season, start_date, first_game, last_game, season_type, created_at, updated_at, status) FROM '$$PATH$$/2282.dat';

--
-- Name: time_frames_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.time_frames_id_seq', 1415, true);


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.users (id, name, email, password, username, role, balance, status, wins, loses, history_count, history_entry, history_winning, remember_token, created_at, updated_at) FROM stdin;
\.
COPY public.users (id, name, email, password, username, role, balance, status, wins, loses, history_count, history_entry, history_winning, remember_token, created_at, updated_at) FROM '$$PATH$$/2284.dat';

--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.users_id_seq', 48, true);


--
-- Name: bit_coin_infos_id_unique; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.bit_coin_infos
    ADD CONSTRAINT bit_coin_infos_id_unique UNIQUE (id);


--
-- Name: contests_id_unique; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.contests
    ADD CONSTRAINT contests_id_unique UNIQUE (id);


--
-- Name: entries_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.entries
    ADD CONSTRAINT entries_pkey PRIMARY KEY (id);


--
-- Name: fantasy_players_id_unique; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.fantasy_players
    ADD CONSTRAINT fantasy_players_id_unique UNIQUE (id);


--
-- Name: games_id_unique; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.games
    ADD CONSTRAINT games_id_unique UNIQUE (id);


--
-- Name: invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: promo_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.promo_codes
    ADD CONSTRAINT promo_codes_pkey PRIMARY KEY (id);


--
-- Name: slates_id_unique; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.slates
    ADD CONSTRAINT slates_id_unique UNIQUE (id);


--
-- Name: time_frames_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.time_frames
    ADD CONSTRAINT time_frames_pkey PRIMARY KEY (id);


--
-- Name: users_email_unique; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users_username_unique; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_unique UNIQUE (username);


--
-- Name: fantasy_index; Type: INDEX; Schema: public; Owner: root
--

CREATE UNIQUE INDEX fantasy_index ON public.fantasy_players USING btree (id);


--
-- Name: fantasy_player_slate_fantasy_player_id_index; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX fantasy_player_slate_fantasy_player_id_index ON public.fantasy_player_slate USING btree (fantasy_player_id);


--
-- Name: fantasy_player_slate_slate_id_index; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX fantasy_player_slate_slate_id_index ON public.fantasy_player_slate USING btree (slate_id);


--
-- Name: game_index; Type: INDEX; Schema: public; Owner: root
--

CREATE UNIQUE INDEX game_index ON public.games USING btree (id);


--
-- Name: game_slate_game_id_index; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX game_slate_game_id_index ON public.game_slate USING btree (game_id);


--
-- Name: game_slate_slate_id_index; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX game_slate_slate_id_index ON public.game_slate USING btree (slate_id);


--
-- Name: password_resets_email_index; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX password_resets_email_index ON public.password_resets USING btree (email);


--
-- Name: slate_index; Type: INDEX; Schema: public; Owner: root
--

CREATE UNIQUE INDEX slate_index ON public.slates USING btree (id);


--
-- Name: fantasy_player_slate_fantasy_player_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.fantasy_player_slate
    ADD CONSTRAINT fantasy_player_slate_fantasy_player_id_foreign FOREIGN KEY (fantasy_player_id) REFERENCES public.fantasy_players(id);


--
-- Name: fantasy_player_slate_slate_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.fantasy_player_slate
    ADD CONSTRAINT fantasy_player_slate_slate_id_foreign FOREIGN KEY (slate_id) REFERENCES public.slates(id);


--
-- Name: game_slate_game_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.game_slate
    ADD CONSTRAINT game_slate_game_id_foreign FOREIGN KEY (game_id) REFERENCES public.games(id) ON DELETE CASCADE;


--
-- Name: game_slate_slate_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.game_slate
    ADD CONSTRAINT game_slate_slate_id_foreign FOREIGN KEY (slate_id) REFERENCES public.slates(id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

