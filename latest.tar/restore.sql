--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.4 (Ubuntu 10.4-2.pgdg18.04+1)
-- Dumped by pg_dump version 10.4 (Ubuntu 10.4-2.pgdg18.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.thread_subscriptions DROP CONSTRAINT thread_subscriptions_thread_id_foreign;
ALTER TABLE ONLY public.game_slate DROP CONSTRAINT game_slate_slate_id_foreign;
ALTER TABLE ONLY public.game_slate DROP CONSTRAINT game_slate_game_id_foreign;
ALTER TABLE ONLY public.fantasy_player_slate DROP CONSTRAINT fantasy_player_slate_slate_id_foreign;
ALTER TABLE ONLY public.fantasy_player_slate DROP CONSTRAINT fantasy_player_slate_fantasy_player_id_foreign;
DROP INDEX public.slate_index;
DROP INDEX public.password_resets_email_index;
DROP INDEX public.notifications_notifiable_id_notifiable_type_index;
DROP INDEX public.game_slate_slate_id_index;
DROP INDEX public.game_slate_game_id_index;
DROP INDEX public.game_index;
DROP INDEX public.fantasy_player_slate_slate_id_index;
DROP INDEX public.fantasy_player_slate_fantasy_player_id_index;
DROP INDEX public.fantasy_index;
DROP INDEX public.activities_user_id_index;
DROP INDEX public.activities_subject_id_index;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_username_unique;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_email_unique;
ALTER TABLE ONLY public.time_frames DROP CONSTRAINT time_frames_pkey;
ALTER TABLE ONLY public.threads DROP CONSTRAINT threads_pkey;
ALTER TABLE ONLY public.thread_subscriptions DROP CONSTRAINT thread_subscriptions_user_id_thread_id_unique;
ALTER TABLE ONLY public.thread_subscriptions DROP CONSTRAINT thread_subscriptions_pkey;
ALTER TABLE ONLY public.slates DROP CONSTRAINT slates_id_unique;
ALTER TABLE ONLY public.replies DROP CONSTRAINT replies_pkey;
ALTER TABLE ONLY public.ranking_weeks DROP CONSTRAINT ranking_weeks_pkey;
ALTER TABLE ONLY public.ranking_months DROP CONSTRAINT ranking_months_pkey;
ALTER TABLE ONLY public.promo_codes DROP CONSTRAINT promo_codes_pkey;
ALTER TABLE ONLY public.posts DROP CONSTRAINT posts_pkey;
ALTER TABLE ONLY public.notifications DROP CONSTRAINT notifications_pkey;
ALTER TABLE ONLY public.migrations DROP CONSTRAINT migrations_pkey;
ALTER TABLE ONLY public.invoices DROP CONSTRAINT invoices_pkey;
ALTER TABLE ONLY public.games DROP CONSTRAINT games_id_unique;
ALTER TABLE ONLY public.favorites DROP CONSTRAINT favorites_user_id_favorited_id_favorited_type_unique;
ALTER TABLE ONLY public.favorites DROP CONSTRAINT favorites_pkey;
ALTER TABLE ONLY public.fantasy_players DROP CONSTRAINT fantasy_players_id_unique;
ALTER TABLE ONLY public.entries DROP CONSTRAINT entries_pkey;
ALTER TABLE ONLY public.contests DROP CONSTRAINT contests_id_unique;
ALTER TABLE ONLY public.comments DROP CONSTRAINT comments_pkey;
ALTER TABLE ONLY public.checks DROP CONSTRAINT checks_pkey;
ALTER TABLE ONLY public.checkbook_tokens DROP CONSTRAINT checkbook_tokens_pkey;
ALTER TABLE ONLY public.channels DROP CONSTRAINT channels_pkey;
ALTER TABLE ONLY public.categories DROP CONSTRAINT category_pkey;
ALTER TABLE ONLY public.bit_coin_infos DROP CONSTRAINT bit_coin_infos_id_unique;
ALTER TABLE ONLY public.activities DROP CONSTRAINT activities_pkey;
ALTER TABLE public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.time_frames ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.threads ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.thread_subscriptions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.replies ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ranking_weeks ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.ranking_months ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.promo_codes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.posts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.migrations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.invoices ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.favorites ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.entries ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.comments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.checks ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.checkbook_tokens ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.channels ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.activities ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.users_id_seq;
DROP TABLE public.users;
DROP SEQUENCE public.time_frames_id_seq;
DROP TABLE public.time_frames;
DROP SEQUENCE public.threads_id_seq;
DROP TABLE public.threads;
DROP SEQUENCE public.thread_subscriptions_id_seq;
DROP TABLE public.thread_subscriptions;
DROP TABLE public.slates;
DROP SEQUENCE public.replies_id_seq;
DROP TABLE public.replies;
DROP SEQUENCE public.ranking_weeks_id_seq;
DROP TABLE public.ranking_weeks;
DROP SEQUENCE public.ranking_months_id_seq;
DROP TABLE public.ranking_months;
DROP SEQUENCE public.promo_codes_id_seq;
DROP TABLE public.promo_codes;
DROP SEQUENCE public.posts_id_seq;
DROP TABLE public.posts;
DROP TABLE public.password_resets;
DROP TABLE public.notifications;
DROP SEQUENCE public.migrations_id_seq;
DROP TABLE public.migrations;
DROP SEQUENCE public.invoices_id_seq;
DROP TABLE public.invoices;
DROP TABLE public.games;
DROP TABLE public.game_slate;
DROP SEQUENCE public.favorites_id_seq;
DROP TABLE public.favorites;
DROP TABLE public.fantasy_players;
DROP TABLE public.fantasy_player_slate;
DROP SEQUENCE public.entries_id_seq;
DROP TABLE public.entries;
DROP TABLE public.contests;
DROP SEQUENCE public.comments_id_seq;
DROP TABLE public.comments;
DROP SEQUENCE public.checks_id_seq;
DROP TABLE public.checks;
DROP SEQUENCE public.checkbook_tokens_id_seq;
DROP TABLE public.checkbook_tokens;
DROP SEQUENCE public.channels_id_seq;
DROP TABLE public.channels;
DROP TABLE public.categories;
DROP TABLE public.bit_coin_infos;
DROP SEQUENCE public.activities_id_seq;
DROP TABLE public.activities;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: activities; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.activities (
    id integer NOT NULL,
    user_id integer NOT NULL,
    subject_id integer NOT NULL,
    subject_type character varying(50) NOT NULL,
    type character varying(50) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.activities OWNER TO root;

--
-- Name: activities_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.activities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.activities_id_seq OWNER TO root;

--
-- Name: activities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.activities_id_seq OWNED BY public.activities.id;


--
-- Name: bit_coin_infos; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.bit_coin_infos (
    id character varying(255) NOT NULL,
    rate double precision,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    key character varying(255)
);


ALTER TABLE public.bit_coin_infos OWNER TO root;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categories (
    id bigint NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.categories OWNER TO postgres;

--
-- Name: channels; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.channels (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    slug character varying(50) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    description text,
    creator integer,
    lock_status boolean
);


ALTER TABLE public.channels OWNER TO root;

--
-- Name: channels_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.channels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.channels_id_seq OWNER TO root;

--
-- Name: channels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.channels_id_seq OWNED BY public.channels.id;


--
-- Name: checkbook_tokens; Type: TABLE; Schema: public; Owner: osboxes
--

CREATE TABLE public.checkbook_tokens (
    id integer NOT NULL,
    "time" character varying(20),
    token character varying(100),
    refreshtoken character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.checkbook_tokens OWNER TO osboxes;

--
-- Name: checkbook_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: osboxes
--

CREATE SEQUENCE public.checkbook_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.checkbook_tokens_id_seq OWNER TO osboxes;

--
-- Name: checkbook_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: osboxes
--

ALTER SEQUENCE public.checkbook_tokens_id_seq OWNED BY public.checkbook_tokens.id;


--
-- Name: checks; Type: TABLE; Schema: public; Owner: osboxes
--

CREATE TABLE public.checks (
    id integer NOT NULL,
    user_id integer,
    email character varying(20),
    amount double precision DEFAULT 0 NOT NULL,
    description character varying(100),
    status character varying(100),
    image_uri character varying(100),
    gen_time character varying(100),
    checkid character varying(100),
    type character varying(20),
    checked boolean DEFAULT false NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.checks OWNER TO osboxes;

--
-- Name: checks_id_seq; Type: SEQUENCE; Schema: public; Owner: osboxes
--

CREATE SEQUENCE public.checks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.checks_id_seq OWNER TO osboxes;

--
-- Name: checks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: osboxes
--

ALTER SEQUENCE public.checks_id_seq OWNED BY public.checks.id;


--
-- Name: comments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.comments (
    id bigint NOT NULL,
    body text NOT NULL,
    post_id integer NOT NULL,
    user_id integer NOT NULL,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone
);


ALTER TABLE public.comments OWNER TO postgres;

--
-- Name: comments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.comments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.comments_id_seq OWNER TO postgres;

--
-- Name: comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.comments_id_seq OWNED BY public.comments.id;


--
-- Name: contests; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.contests (
    id character varying(255) NOT NULL,
    "matchupType" character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    size integer NOT NULL,
    "entryFee" integer NOT NULL,
    tier character varying(255),
    "position" character varying(255) NOT NULL,
    filled boolean NOT NULL,
    status character varying(255) NOT NULL,
    slate_id character varying(255) NOT NULL,
    start timestamp(0) without time zone NOT NULL,
    user_id integer NOT NULL,
    group_id character varying(255),
    admin_contest boolean DEFAULT false NOT NULL,
    private boolean DEFAULT false NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    credit_applied boolean
);


ALTER TABLE public.contests OWNER TO root;

--
-- Name: entries; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.entries (
    id integer NOT NULL,
    contest_id character varying(255) NOT NULL,
    slate_id character varying(255) NOT NULL,
    user_id integer,
    username character varying(255),
    fantasy_player_id character varying(255) NOT NULL,
    game_id character varying(255) NOT NULL,
    owner boolean NOT NULL,
    points double precision DEFAULT '0'::double precision NOT NULL,
    winning double precision DEFAULT '0'::double precision NOT NULL,
    winner boolean DEFAULT false NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.entries OWNER TO root;

--
-- Name: entries_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.entries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.entries_id_seq OWNER TO root;

--
-- Name: entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.entries_id_seq OWNED BY public.entries.id;


--
-- Name: fantasy_player_slate; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.fantasy_player_slate (
    fantasy_player_id character varying(255) NOT NULL,
    slate_id character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.fantasy_player_slate OWNER TO root;

--
-- Name: fantasy_players; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.fantasy_players (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    team character varying(255) NOT NULL,
    game_id character varying(255),
    "position" character varying(255) NOT NULL,
    status character varying(255),
    status_code character varying(255),
    status_color character varying(255),
    tier character varying(255),
    salary integer NOT NULL,
    activated boolean DEFAULT false NOT NULL,
    played boolean DEFAULT false NOT NULL,
    tds character varying(255) DEFAULT '0'::character varying NOT NULL,
    "paYd" character varying(255) DEFAULT '0'::character varying NOT NULL,
    "paTd" character varying(255) DEFAULT '0'::character varying NOT NULL,
    "int" character varying(255) DEFAULT '0'::character varying NOT NULL,
    "ruYd" character varying(255) DEFAULT '0'::character varying NOT NULL,
    "ruTd" character varying(255) DEFAULT '0'::character varying NOT NULL,
    fum character varying(255) DEFAULT '0'::character varying NOT NULL,
    rec character varying(255) DEFAULT '0'::character varying NOT NULL,
    "reYd" character varying(255) DEFAULT '0'::character varying NOT NULL,
    "reTd" character varying(255) DEFAULT '0'::character varying NOT NULL,
    "krTd" character varying(255) DEFAULT '0'::character varying NOT NULL,
    "prTd" character varying(255) DEFAULT '0'::character varying NOT NULL,
    "frTd" character varying(255) DEFAULT '0'::character varying NOT NULL,
    "convRec" character varying(255) DEFAULT '0'::character varying NOT NULL,
    "convPass" character varying(255) DEFAULT '0'::character varying NOT NULL,
    "convRuns" character varying(255) DEFAULT '0'::character varying NOT NULL,
    fg0_39 character varying(255) DEFAULT '0'::character varying NOT NULL,
    fg40_49 character varying(255) DEFAULT '0'::character varying NOT NULL,
    fg50 character varying(255) DEFAULT '0'::character varying NOT NULL,
    xp character varying(255) DEFAULT '0'::character varying NOT NULL,
    sacks character varying(255) DEFAULT '0'::character varying NOT NULL,
    "defInt" character varying(255) DEFAULT '0'::character varying NOT NULL,
    "fumRec" character varying(255) DEFAULT '0'::character varying NOT NULL,
    safeties character varying(255) DEFAULT '0'::character varying NOT NULL,
    "defTds" character varying(255) DEFAULT '0'::character varying NOT NULL,
    "ptsA" character varying(255) DEFAULT '0'::character varying NOT NULL,
    "convRet" character varying(255) DEFAULT '0'::character varying NOT NULL,
    fps character varying(255) DEFAULT '0'::character varying NOT NULL,
    fps_live character varying(255) DEFAULT '0'::character varying NOT NULL,
    active boolean DEFAULT true NOT NULL,
    updated boolean DEFAULT false NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.fantasy_players OWNER TO root;

--
-- Name: favorites; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.favorites (
    id integer NOT NULL,
    user_id integer NOT NULL,
    favorited_id integer NOT NULL,
    favorited_type character varying(50) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.favorites OWNER TO root;

--
-- Name: favorites_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.favorites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.favorites_id_seq OWNER TO root;

--
-- Name: favorites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.favorites_id_seq OWNED BY public.favorites.id;


--
-- Name: game_slate; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.game_slate (
    game_id character varying(255) NOT NULL,
    slate_id character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.game_slate OWNER TO root;

--
-- Name: games; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.games (
    id character varying(255) NOT NULL,
    year character varying(255) NOT NULL,
    "seasonType" character varying(255) NOT NULL,
    week character varying(255) NOT NULL,
    day character varying(255) NOT NULL,
    date timestamp(0) without time zone NOT NULL,
    "time" character varying(255) NOT NULL,
    "homeScore" integer NOT NULL,
    "awayScore" integer NOT NULL,
    "homeTeam" character varying(255) NOT NULL,
    "awayTeam" character varying(255) NOT NULL,
    status character varying(255) DEFAULT 'PENDING'::character varying NOT NULL,
    quarter character varying(255),
    overtime boolean NOT NULL,
    time_remaining character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    game_key character varying(50) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE public.games OWNER TO root;

--
-- Name: invoices; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.invoices (
    id integer NOT NULL,
    "invoiceId" character varying(255),
    email character varying(255) NOT NULL,
    user_id integer NOT NULL,
    amount double precision NOT NULL,
    currency character varying(255) NOT NULL,
    description character varying(255) NOT NULL,
    status character varying(255) NOT NULL,
    "createdAt" timestamp(0) without time zone,
    type character varying(255) NOT NULL,
    retries integer DEFAULT 0 NOT NULL,
    checked boolean DEFAULT false NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.invoices OWNER TO root;

--
-- Name: invoices_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.invoices_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.invoices_id_seq OWNER TO root;

--
-- Name: invoices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.invoices_id_seq OWNED BY public.invoices.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


ALTER TABLE public.migrations OWNER TO root;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migrations_id_seq OWNER TO root;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.notifications (
    id uuid NOT NULL,
    type character varying(255) NOT NULL,
    notifiable_id integer NOT NULL,
    notifiable_type character varying(255) NOT NULL,
    data text NOT NULL,
    read_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.notifications OWNER TO root;

--
-- Name: password_resets; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.password_resets (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp(0) without time zone
);


ALTER TABLE public.password_resets OWNER TO root;

--
-- Name: posts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.posts (
    category integer NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    author integer NOT NULL,
    image character varying(200) NOT NULL,
    color character varying(10) NOT NULL,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    is_publish boolean,
    id bigint NOT NULL,
    sections json
);


ALTER TABLE public.posts OWNER TO postgres;

--
-- Name: posts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.posts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.posts_id_seq OWNER TO postgres;

--
-- Name: posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.posts_id_seq OWNED BY public.posts.id;


--
-- Name: promo_codes; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.promo_codes (
    id integer NOT NULL,
    email character varying(30) NOT NULL,
    code character varying(20) NOT NULL,
    expired bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.promo_codes OWNER TO root;

--
-- Name: promo_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.promo_codes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.promo_codes_id_seq OWNER TO root;

--
-- Name: promo_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.promo_codes_id_seq OWNED BY public.promo_codes.id;


--
-- Name: ranking_months; Type: TABLE; Schema: public; Owner: osboxes
--

CREATE TABLE public.ranking_months (
    id integer NOT NULL,
    user_id integer NOT NULL,
    score_month_1 double precision DEFAULT 0 NOT NULL,
    score_month_2 double precision DEFAULT 0 NOT NULL,
    score_month_3 double precision DEFAULT 0 NOT NULL,
    score_month_4 double precision DEFAULT 0 NOT NULL,
    score_month_5 double precision DEFAULT 0 NOT NULL,
    score_month_6 double precision DEFAULT 0 NOT NULL,
    score_month_7 double precision DEFAULT 0 NOT NULL,
    score_month_8 double precision DEFAULT 0 NOT NULL,
    score_month_9 double precision DEFAULT 0 NOT NULL,
    score_month_10 double precision DEFAULT 0 NOT NULL,
    score_month_11 double precision DEFAULT 0 NOT NULL,
    score_month_12 double precision DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.ranking_months OWNER TO osboxes;

--
-- Name: ranking_months_id_seq; Type: SEQUENCE; Schema: public; Owner: osboxes
--

CREATE SEQUENCE public.ranking_months_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ranking_months_id_seq OWNER TO osboxes;

--
-- Name: ranking_months_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: osboxes
--

ALTER SEQUENCE public.ranking_months_id_seq OWNED BY public.ranking_months.id;


--
-- Name: ranking_weeks; Type: TABLE; Schema: public; Owner: osboxes
--

CREATE TABLE public.ranking_weeks (
    id integer NOT NULL,
    user_id integer NOT NULL,
    score_week_1 double precision DEFAULT 0 NOT NULL,
    score_week_2 double precision DEFAULT 0 NOT NULL,
    score_week_3 double precision DEFAULT 0 NOT NULL,
    score_week_4 double precision DEFAULT 0 NOT NULL,
    score_week_5 double precision DEFAULT 0 NOT NULL,
    score_week_6 double precision DEFAULT 0 NOT NULL,
    score_week_7 double precision DEFAULT 0 NOT NULL,
    score_week_8 double precision DEFAULT 0 NOT NULL,
    score_week_9 double precision DEFAULT 0 NOT NULL,
    score_week_10 double precision DEFAULT 0 NOT NULL,
    score_week_11 double precision DEFAULT 0 NOT NULL,
    score_week_12 double precision DEFAULT 0 NOT NULL,
    score_week_13 double precision DEFAULT 0 NOT NULL,
    score_week_14 double precision DEFAULT 0 NOT NULL,
    score_week_15 double precision DEFAULT 0 NOT NULL,
    score_week_16 double precision DEFAULT 0 NOT NULL,
    score_week_17 double precision DEFAULT 0 NOT NULL,
    score_week_18 double precision DEFAULT 0 NOT NULL,
    score_week_19 double precision DEFAULT 0 NOT NULL,
    score_week_20 double precision DEFAULT 0 NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.ranking_weeks OWNER TO osboxes;

--
-- Name: ranking_weeks_id_seq; Type: SEQUENCE; Schema: public; Owner: osboxes
--

CREATE SEQUENCE public.ranking_weeks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ranking_weeks_id_seq OWNER TO osboxes;

--
-- Name: ranking_weeks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: osboxes
--

ALTER SEQUENCE public.ranking_weeks_id_seq OWNED BY public.ranking_weeks.id;


--
-- Name: replies; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.replies (
    id integer NOT NULL,
    thread_id integer NOT NULL,
    user_id integer NOT NULL,
    body text NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.replies OWNER TO root;

--
-- Name: replies_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.replies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.replies_id_seq OWNER TO root;

--
-- Name: replies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.replies_id_seq OWNED BY public.replies.id;


--
-- Name: slates; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.slates (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    "firstDay" character varying(255) NOT NULL,
    "lastDay" character varying(255) NOT NULL,
    active boolean NOT NULL,
    status character varying(255) DEFAULT 'PENDING'::character varying NOT NULL,
    "firstGame" timestamp(0) without time zone,
    "lastGame" timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.slates OWNER TO root;

--
-- Name: thread_subscriptions; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.thread_subscriptions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    thread_id integer NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.thread_subscriptions OWNER TO root;

--
-- Name: thread_subscriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.thread_subscriptions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.thread_subscriptions_id_seq OWNER TO root;

--
-- Name: thread_subscriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.thread_subscriptions_id_seq OWNED BY public.thread_subscriptions.id;


--
-- Name: threads; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.threads (
    id integer NOT NULL,
    user_id integer NOT NULL,
    channel_id integer NOT NULL,
    replies_count integer DEFAULT 0 NOT NULL,
    title character varying(255) NOT NULL,
    body text NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    lock_status boolean
);


ALTER TABLE public.threads OWNER TO root;

--
-- Name: threads_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.threads_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.threads_id_seq OWNER TO root;

--
-- Name: threads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.threads_id_seq OWNED BY public.threads.id;


--
-- Name: time_frames; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.time_frames (
    id integer NOT NULL,
    api_week character varying(255),
    api_season character varying(255),
    week character varying(255),
    season character varying(255) NOT NULL,
    start_date timestamp(0) without time zone NOT NULL,
    first_game timestamp(0) without time zone NOT NULL,
    last_game timestamp(0) without time zone NOT NULL,
    season_type character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    status character varying(255) DEFAULT 'current'::character varying NOT NULL
);


ALTER TABLE public.time_frames OWNER TO root;

--
-- Name: time_frames_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.time_frames_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.time_frames_id_seq OWNER TO root;

--
-- Name: time_frames_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.time_frames_id_seq OWNED BY public.time_frames.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.users (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    username character varying(255) NOT NULL,
    role character varying(255) DEFAULT 'user'::character varying NOT NULL,
    balance double precision DEFAULT '0'::double precision NOT NULL,
    status character varying(255) DEFAULT 'active'::character varying NOT NULL,
    wins double precision DEFAULT '0'::double precision NOT NULL,
    loses double precision DEFAULT '0'::double precision NOT NULL,
    history_count double precision DEFAULT '0'::double precision NOT NULL,
    history_entry double precision DEFAULT '0'::double precision NOT NULL,
    history_winning double precision DEFAULT '0'::double precision NOT NULL,
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deposit double precision DEFAULT 0 NOT NULL,
    blog_access boolean DEFAULT false NOT NULL,
    score double precision DEFAULT 0 NOT NULL,
    token character varying(255),
    refresh_token character varying(255),
    gateway character varying(255) DEFAULT 'coinbase'::character varying,
    credit integer,
    contest_worth integer,
    contest_worth_before integer
);


ALTER TABLE public.users OWNER TO root;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO root;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: activities id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.activities ALTER COLUMN id SET DEFAULT nextval('public.activities_id_seq'::regclass);


--
-- Name: channels id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.channels ALTER COLUMN id SET DEFAULT nextval('public.channels_id_seq'::regclass);


--
-- Name: checkbook_tokens id; Type: DEFAULT; Schema: public; Owner: osboxes
--

ALTER TABLE ONLY public.checkbook_tokens ALTER COLUMN id SET DEFAULT nextval('public.checkbook_tokens_id_seq'::regclass);


--
-- Name: checks id; Type: DEFAULT; Schema: public; Owner: osboxes
--

ALTER TABLE ONLY public.checks ALTER COLUMN id SET DEFAULT nextval('public.checks_id_seq'::regclass);


--
-- Name: comments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comments ALTER COLUMN id SET DEFAULT nextval('public.comments_id_seq'::regclass);


--
-- Name: entries id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.entries ALTER COLUMN id SET DEFAULT nextval('public.entries_id_seq'::regclass);


--
-- Name: favorites id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.favorites ALTER COLUMN id SET DEFAULT nextval('public.favorites_id_seq'::regclass);


--
-- Name: invoices id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.invoices ALTER COLUMN id SET DEFAULT nextval('public.invoices_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: posts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts ALTER COLUMN id SET DEFAULT nextval('public.posts_id_seq'::regclass);


--
-- Name: promo_codes id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.promo_codes ALTER COLUMN id SET DEFAULT nextval('public.promo_codes_id_seq'::regclass);


--
-- Name: ranking_months id; Type: DEFAULT; Schema: public; Owner: osboxes
--

ALTER TABLE ONLY public.ranking_months ALTER COLUMN id SET DEFAULT nextval('public.ranking_months_id_seq'::regclass);


--
-- Name: ranking_weeks id; Type: DEFAULT; Schema: public; Owner: osboxes
--

ALTER TABLE ONLY public.ranking_weeks ALTER COLUMN id SET DEFAULT nextval('public.ranking_weeks_id_seq'::regclass);


--
-- Name: replies id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.replies ALTER COLUMN id SET DEFAULT nextval('public.replies_id_seq'::regclass);


--
-- Name: thread_subscriptions id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.thread_subscriptions ALTER COLUMN id SET DEFAULT nextval('public.thread_subscriptions_id_seq'::regclass);


--
-- Name: threads id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.threads ALTER COLUMN id SET DEFAULT nextval('public.threads_id_seq'::regclass);


--
-- Name: time_frames id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.time_frames ALTER COLUMN id SET DEFAULT nextval('public.time_frames_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: activities; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.activities (id, user_id, subject_id, subject_type, type, created_at, updated_at) FROM stdin;
\.
COPY public.activities (id, user_id, subject_id, subject_type, type, created_at, updated_at) FROM '$$PATH$$/3289.dat';

--
-- Data for Name: bit_coin_infos; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.bit_coin_infos (id, rate, created_at, updated_at, key) FROM stdin;
\.
COPY public.bit_coin_infos (id, rate, created_at, updated_at, key) FROM '$$PATH$$/3249.dat';

--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (id, name) FROM stdin;
\.
COPY public.categories (id, name) FROM '$$PATH$$/3278.dat';

--
-- Data for Name: channels; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.channels (id, name, slug, created_at, updated_at, description, creator, lock_status) FROM stdin;
\.
COPY public.channels (id, name, slug, created_at, updated_at, description, creator, lock_status) FROM '$$PATH$$/3285.dat';

--
-- Data for Name: checkbook_tokens; Type: TABLE DATA; Schema: public; Owner: osboxes
--

COPY public.checkbook_tokens (id, "time", token, refreshtoken, created_at, updated_at) FROM stdin;
\.
COPY public.checkbook_tokens (id, "time", token, refreshtoken, created_at, updated_at) FROM '$$PATH$$/3274.dat';

--
-- Data for Name: checks; Type: TABLE DATA; Schema: public; Owner: osboxes
--

COPY public.checks (id, user_id, email, amount, description, status, image_uri, gen_time, checkid, type, checked, created_at, updated_at) FROM stdin;
\.
COPY public.checks (id, user_id, email, amount, description, status, image_uri, gen_time, checkid, type, checked, created_at, updated_at) FROM '$$PATH$$/3276.dat';

--
-- Data for Name: comments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.comments (id, body, post_id, user_id, created_at, updated_at) FROM stdin;
\.
COPY public.comments (id, body, post_id, user_id, created_at, updated_at) FROM '$$PATH$$/3280.dat';

--
-- Data for Name: contests; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.contests (id, "matchupType", type, size, "entryFee", tier, "position", filled, status, slate_id, start, user_id, group_id, admin_contest, private, created_at, updated_at, credit_applied) FROM stdin;
\.
COPY public.contests (id, "matchupType", type, size, "entryFee", tier, "position", filled, status, slate_id, start, user_id, group_id, admin_contest, private, created_at, updated_at, credit_applied) FROM '$$PATH$$/3250.dat';

--
-- Data for Name: entries; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.entries (id, contest_id, slate_id, user_id, username, fantasy_player_id, game_id, owner, points, winning, winner, created_at, updated_at) FROM stdin;
\.
COPY public.entries (id, contest_id, slate_id, user_id, username, fantasy_player_id, game_id, owner, points, winning, winner, created_at, updated_at) FROM '$$PATH$$/3251.dat';

--
-- Data for Name: fantasy_player_slate; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.fantasy_player_slate (fantasy_player_id, slate_id, created_at, updated_at) FROM stdin;
\.
COPY public.fantasy_player_slate (fantasy_player_id, slate_id, created_at, updated_at) FROM '$$PATH$$/3253.dat';

--
-- Data for Name: fantasy_players; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.fantasy_players (id, name, team, game_id, "position", status, status_code, status_color, tier, salary, activated, played, tds, "paYd", "paTd", "int", "ruYd", "ruTd", fum, rec, "reYd", "reTd", "krTd", "prTd", "frTd", "convRec", "convPass", "convRuns", fg0_39, fg40_49, fg50, xp, sacks, "defInt", "fumRec", safeties, "defTds", "ptsA", "convRet", fps, fps_live, active, updated, created_at, updated_at) FROM stdin;
\.
COPY public.fantasy_players (id, name, team, game_id, "position", status, status_code, status_color, tier, salary, activated, played, tds, "paYd", "paTd", "int", "ruYd", "ruTd", fum, rec, "reYd", "reTd", "krTd", "prTd", "frTd", "convRec", "convPass", "convRuns", fg0_39, fg40_49, fg50, xp, sacks, "defInt", "fumRec", safeties, "defTds", "ptsA", "convRet", fps, fps_live, active, updated, created_at, updated_at) FROM '$$PATH$$/3254.dat';

--
-- Data for Name: favorites; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.favorites (id, user_id, favorited_id, favorited_type, created_at, updated_at) FROM stdin;
\.
COPY public.favorites (id, user_id, favorited_id, favorited_type, created_at, updated_at) FROM '$$PATH$$/3287.dat';

--
-- Data for Name: game_slate; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.game_slate (game_id, slate_id, created_at, updated_at) FROM stdin;
\.
COPY public.game_slate (game_id, slate_id, created_at, updated_at) FROM '$$PATH$$/3255.dat';

--
-- Data for Name: games; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.games (id, year, "seasonType", week, day, date, "time", "homeScore", "awayScore", "homeTeam", "awayTeam", status, quarter, overtime, time_remaining, created_at, updated_at, game_key) FROM stdin;
\.
COPY public.games (id, year, "seasonType", week, day, date, "time", "homeScore", "awayScore", "homeTeam", "awayTeam", status, quarter, overtime, time_remaining, created_at, updated_at, game_key) FROM '$$PATH$$/3256.dat';

--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.invoices (id, "invoiceId", email, user_id, amount, currency, description, status, "createdAt", type, retries, checked, created_at, updated_at) FROM stdin;
\.
COPY public.invoices (id, "invoiceId", email, user_id, amount, currency, description, status, "createdAt", type, retries, checked, created_at, updated_at) FROM '$$PATH$$/3257.dat';

--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.migrations (id, migration, batch) FROM stdin;
\.
COPY public.migrations (id, migration, batch) FROM '$$PATH$$/3259.dat';

--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.notifications (id, type, notifiable_id, notifiable_type, data, read_at, created_at, updated_at) FROM stdin;
\.
COPY public.notifications (id, type, notifiable_id, notifiable_type, data, read_at, created_at, updated_at) FROM '$$PATH$$/3294.dat';

--
-- Data for Name: password_resets; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.password_resets (email, token, created_at) FROM stdin;
\.
COPY public.password_resets (email, token, created_at) FROM '$$PATH$$/3261.dat';

--
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.posts (category, title, description, author, image, color, created_at, updated_at, is_publish, id, sections) FROM stdin;
\.
COPY public.posts (category, title, description, author, image, color, created_at, updated_at, is_publish, id, sections) FROM '$$PATH$$/3277.dat';

--
-- Data for Name: promo_codes; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.promo_codes (id, email, code, expired, created_at, updated_at) FROM stdin;
\.
COPY public.promo_codes (id, email, code, expired, created_at, updated_at) FROM '$$PATH$$/3262.dat';

--
-- Data for Name: ranking_months; Type: TABLE DATA; Schema: public; Owner: osboxes
--

COPY public.ranking_months (id, user_id, score_month_1, score_month_2, score_month_3, score_month_4, score_month_5, score_month_6, score_month_7, score_month_8, score_month_9, score_month_10, score_month_11, score_month_12, created_at, updated_at) FROM stdin;
\.
COPY public.ranking_months (id, user_id, score_month_1, score_month_2, score_month_3, score_month_4, score_month_5, score_month_6, score_month_7, score_month_8, score_month_9, score_month_10, score_month_11, score_month_12, created_at, updated_at) FROM '$$PATH$$/3270.dat';

--
-- Data for Name: ranking_weeks; Type: TABLE DATA; Schema: public; Owner: osboxes
--

COPY public.ranking_weeks (id, user_id, score_week_1, score_week_2, score_week_3, score_week_4, score_week_5, score_week_6, score_week_7, score_week_8, score_week_9, score_week_10, score_week_11, score_week_12, score_week_13, score_week_14, score_week_15, score_week_16, score_week_17, score_week_18, score_week_19, score_week_20, created_at, updated_at) FROM stdin;
\.
COPY public.ranking_weeks (id, user_id, score_week_1, score_week_2, score_week_3, score_week_4, score_week_5, score_week_6, score_week_7, score_week_8, score_week_9, score_week_10, score_week_11, score_week_12, score_week_13, score_week_14, score_week_15, score_week_16, score_week_17, score_week_18, score_week_19, score_week_20, created_at, updated_at) FROM '$$PATH$$/3272.dat';

--
-- Data for Name: replies; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.replies (id, thread_id, user_id, body, created_at, updated_at) FROM stdin;
\.
COPY public.replies (id, thread_id, user_id, body, created_at, updated_at) FROM '$$PATH$$/3283.dat';

--
-- Data for Name: slates; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.slates (id, name, "firstDay", "lastDay", active, status, "firstGame", "lastGame", created_at, updated_at) FROM stdin;
\.
COPY public.slates (id, name, "firstDay", "lastDay", active, status, "firstGame", "lastGame", created_at, updated_at) FROM '$$PATH$$/3264.dat';

--
-- Data for Name: thread_subscriptions; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.thread_subscriptions (id, user_id, thread_id, created_at, updated_at) FROM stdin;
\.
COPY public.thread_subscriptions (id, user_id, thread_id, created_at, updated_at) FROM '$$PATH$$/3293.dat';

--
-- Data for Name: threads; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.threads (id, user_id, channel_id, replies_count, title, body, created_at, updated_at, lock_status) FROM stdin;
\.
COPY public.threads (id, user_id, channel_id, replies_count, title, body, created_at, updated_at, lock_status) FROM '$$PATH$$/3291.dat';

--
-- Data for Name: time_frames; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.time_frames (id, api_week, api_season, week, season, start_date, first_game, last_game, season_type, created_at, updated_at, status) FROM stdin;
\.
COPY public.time_frames (id, api_week, api_season, week, season, start_date, first_game, last_game, season_type, created_at, updated_at, status) FROM '$$PATH$$/3265.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.users (id, name, email, password, username, role, balance, status, wins, loses, history_count, history_entry, history_winning, remember_token, created_at, updated_at, deposit, blog_access, score, token, refresh_token, gateway, credit, contest_worth, contest_worth_before) FROM stdin;
\.
COPY public.users (id, name, email, password, username, role, balance, status, wins, loses, history_count, history_entry, history_winning, remember_token, created_at, updated_at, deposit, blog_access, score, token, refresh_token, gateway, credit, contest_worth, contest_worth_before) FROM '$$PATH$$/3267.dat';

--
-- Name: activities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.activities_id_seq', 62, true);


--
-- Name: channels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.channels_id_seq', 17, true);


--
-- Name: checkbook_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: osboxes
--

SELECT pg_catalog.setval('public.checkbook_tokens_id_seq', 4, true);


--
-- Name: checks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: osboxes
--

SELECT pg_catalog.setval('public.checks_id_seq', 23, true);


--
-- Name: comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.comments_id_seq', 12, true);


--
-- Name: entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.entries_id_seq', 1788, true);


--
-- Name: favorites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.favorites_id_seq', 1, false);


--
-- Name: invoices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.invoices_id_seq', 121, true);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.migrations_id_seq', 44, true);


--
-- Name: posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.posts_id_seq', 154, true);


--
-- Name: promo_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.promo_codes_id_seq', 7, true);


--
-- Name: ranking_months_id_seq; Type: SEQUENCE SET; Schema: public; Owner: osboxes
--

SELECT pg_catalog.setval('public.ranking_months_id_seq', 49, true);


--
-- Name: ranking_weeks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: osboxes
--

SELECT pg_catalog.setval('public.ranking_weeks_id_seq', 49, true);


--
-- Name: replies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.replies_id_seq', 38, true);


--
-- Name: thread_subscriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.thread_subscriptions_id_seq', 1, false);


--
-- Name: threads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.threads_id_seq', 25, true);


--
-- Name: time_frames_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.time_frames_id_seq', 1472, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.users_id_seq', 61, true);


--
-- Name: activities activities_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT activities_pkey PRIMARY KEY (id);


--
-- Name: bit_coin_infos bit_coin_infos_id_unique; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.bit_coin_infos
    ADD CONSTRAINT bit_coin_infos_id_unique UNIQUE (id);


--
-- Name: categories category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT category_pkey PRIMARY KEY (id);


--
-- Name: channels channels_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.channels
    ADD CONSTRAINT channels_pkey PRIMARY KEY (id);


--
-- Name: checkbook_tokens checkbook_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: osboxes
--

ALTER TABLE ONLY public.checkbook_tokens
    ADD CONSTRAINT checkbook_tokens_pkey PRIMARY KEY (id);


--
-- Name: checks checks_pkey; Type: CONSTRAINT; Schema: public; Owner: osboxes
--

ALTER TABLE ONLY public.checks
    ADD CONSTRAINT checks_pkey PRIMARY KEY (id);


--
-- Name: comments comments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_pkey PRIMARY KEY (id);


--
-- Name: contests contests_id_unique; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.contests
    ADD CONSTRAINT contests_id_unique UNIQUE (id);


--
-- Name: entries entries_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.entries
    ADD CONSTRAINT entries_pkey PRIMARY KEY (id);


--
-- Name: fantasy_players fantasy_players_id_unique; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.fantasy_players
    ADD CONSTRAINT fantasy_players_id_unique UNIQUE (id);


--
-- Name: favorites favorites_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.favorites
    ADD CONSTRAINT favorites_pkey PRIMARY KEY (id);


--
-- Name: favorites favorites_user_id_favorited_id_favorited_type_unique; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.favorites
    ADD CONSTRAINT favorites_user_id_favorited_id_favorited_type_unique UNIQUE (user_id, favorited_id, favorited_type);


--
-- Name: games games_id_unique; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.games
    ADD CONSTRAINT games_id_unique UNIQUE (id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: posts posts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_pkey PRIMARY KEY (id);


--
-- Name: promo_codes promo_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.promo_codes
    ADD CONSTRAINT promo_codes_pkey PRIMARY KEY (id);


--
-- Name: ranking_months ranking_months_pkey; Type: CONSTRAINT; Schema: public; Owner: osboxes
--

ALTER TABLE ONLY public.ranking_months
    ADD CONSTRAINT ranking_months_pkey PRIMARY KEY (id);


--
-- Name: ranking_weeks ranking_weeks_pkey; Type: CONSTRAINT; Schema: public; Owner: osboxes
--

ALTER TABLE ONLY public.ranking_weeks
    ADD CONSTRAINT ranking_weeks_pkey PRIMARY KEY (id);


--
-- Name: replies replies_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.replies
    ADD CONSTRAINT replies_pkey PRIMARY KEY (id);


--
-- Name: slates slates_id_unique; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.slates
    ADD CONSTRAINT slates_id_unique UNIQUE (id);


--
-- Name: thread_subscriptions thread_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.thread_subscriptions
    ADD CONSTRAINT thread_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: thread_subscriptions thread_subscriptions_user_id_thread_id_unique; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.thread_subscriptions
    ADD CONSTRAINT thread_subscriptions_user_id_thread_id_unique UNIQUE (user_id, thread_id);


--
-- Name: threads threads_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.threads
    ADD CONSTRAINT threads_pkey PRIMARY KEY (id);


--
-- Name: time_frames time_frames_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.time_frames
    ADD CONSTRAINT time_frames_pkey PRIMARY KEY (id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_unique; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_unique UNIQUE (username);


--
-- Name: activities_subject_id_index; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX activities_subject_id_index ON public.activities USING btree (subject_id);


--
-- Name: activities_user_id_index; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX activities_user_id_index ON public.activities USING btree (user_id);


--
-- Name: fantasy_index; Type: INDEX; Schema: public; Owner: root
--

CREATE UNIQUE INDEX fantasy_index ON public.fantasy_players USING btree (id);


--
-- Name: fantasy_player_slate_fantasy_player_id_index; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX fantasy_player_slate_fantasy_player_id_index ON public.fantasy_player_slate USING btree (fantasy_player_id);


--
-- Name: fantasy_player_slate_slate_id_index; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX fantasy_player_slate_slate_id_index ON public.fantasy_player_slate USING btree (slate_id);


--
-- Name: game_index; Type: INDEX; Schema: public; Owner: root
--

CREATE UNIQUE INDEX game_index ON public.games USING btree (id);


--
-- Name: game_slate_game_id_index; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX game_slate_game_id_index ON public.game_slate USING btree (game_id);


--
-- Name: game_slate_slate_id_index; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX game_slate_slate_id_index ON public.game_slate USING btree (slate_id);


--
-- Name: notifications_notifiable_id_notifiable_type_index; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX notifications_notifiable_id_notifiable_type_index ON public.notifications USING btree (notifiable_id, notifiable_type);


--
-- Name: password_resets_email_index; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX password_resets_email_index ON public.password_resets USING btree (email);


--
-- Name: slate_index; Type: INDEX; Schema: public; Owner: root
--

CREATE UNIQUE INDEX slate_index ON public.slates USING btree (id);


--
-- Name: fantasy_player_slate fantasy_player_slate_fantasy_player_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.fantasy_player_slate
    ADD CONSTRAINT fantasy_player_slate_fantasy_player_id_foreign FOREIGN KEY (fantasy_player_id) REFERENCES public.fantasy_players(id);


--
-- Name: fantasy_player_slate fantasy_player_slate_slate_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.fantasy_player_slate
    ADD CONSTRAINT fantasy_player_slate_slate_id_foreign FOREIGN KEY (slate_id) REFERENCES public.slates(id);


--
-- Name: game_slate game_slate_game_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.game_slate
    ADD CONSTRAINT game_slate_game_id_foreign FOREIGN KEY (game_id) REFERENCES public.games(id) ON DELETE CASCADE;


--
-- Name: game_slate game_slate_slate_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.game_slate
    ADD CONSTRAINT game_slate_slate_id_foreign FOREIGN KEY (slate_id) REFERENCES public.slates(id) ON DELETE CASCADE;


--
-- Name: thread_subscriptions thread_subscriptions_thread_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.thread_subscriptions
    ADD CONSTRAINT thread_subscriptions_thread_id_foreign FOREIGN KEY (thread_id) REFERENCES public.threads(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

